# Kubernetes Monitoring chart

The source for the Kubernetes Monitoring Helm chart can be found at
<https://github.com/grafana/k8s-monitoring-helm>.
Releases of the chart are still published to the <https://grafana.github.io/helm-charts>
repository.

If you have any issues with this chart, please file them on the [Kubernetes Monitoring Helm chart](https://github.com/grafana/k8s-monitoring-helm) repository.
